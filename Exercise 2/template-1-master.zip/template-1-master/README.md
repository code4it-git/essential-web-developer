
[![N|Solid](http://code4it.org/img/logo.png)](https://nodesource.com/products/nsolid)

This is our web development basic class' template.
With this template you are going to be able to:

  - Have an html playgound
  - Add Images
  - Add Javascript content
  - Have a template for your future projects

You can also:
  - Use the code for your personal projects
  - Add more pages with the same style

If you want to know more about Code4IT, please go to our [main page][df1]

> Please use your favorite IDE for make changes in this template.

> This template is based on Overflow by HTML5 UP
html5up.net | @ajlkn
Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)

 [df1]: <http://code4it.org>
  